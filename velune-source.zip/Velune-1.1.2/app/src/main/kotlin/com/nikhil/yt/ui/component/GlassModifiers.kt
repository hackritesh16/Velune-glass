package com.nikhil.yt.ui.component

import androidx.compose.foundation.border
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Specular glass rim: bright at the top-left "light source", fading through the
 * (optional) accent colour, and catching a little light again at the bottom-right.
 * Much more convincing than a flat 1dp outline, and costs nothing at draw time.
 */
fun Modifier.glassBorder(
    shape: Shape,
    isDark: Boolean,
    accent: Color = Color.Unspecified,
    width: Dp = 1.dp,
): Modifier {
    val tint = if (accent == Color.Unspecified) Color.White else accent
    val brush = Brush.linearGradient(
        colors = listOf(
            Color.White.copy(alpha = if (isDark) 0.42f else 0.80f),
            tint.copy(alpha = if (isDark) 0.12f else 0.18f),
            Color.White.copy(alpha = if (isDark) 0.05f else 0.18f),
            Color.White.copy(alpha = if (isDark) 0.24f else 0.55f),
        ),
    )
    return this.border(width = width, brush = brush, shape = shape)
}

/** Soft top-down sheen drawn over a glass surface (use inside `onDrawSurface`). */
fun glassSheenBrush(alpha: Float, heightPx: Float): Brush =
    Brush.verticalGradient(
        colors = listOf(Color.White.copy(alpha = alpha), Color.Transparent),
        startY = 0f,
        endY = heightPx,
    )
